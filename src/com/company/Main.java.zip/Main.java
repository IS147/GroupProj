import java.util.Random;

public class Main {

    public static void main(String[] args) {

        Intro();
        NotifierArray();

    }

    public static void NotifierArray() {

        Random random = new Random();

        //CODE FOR ITEM LIST
        String itemList[] = {"Cookies", "Bread", "Apples", "Pasta", "Egg", "Milk", "Bacon"};



        //CREATION OF ARRAY
        int sum = 0;
        int quantityList[] = new int[7];

        //LOOP FOR VALUE OF EACH ITEM THROUGH A RANDOM NUMBER
        for (int i = 0; i < quantityList.length; i++)
            quantityList[i] = random.nextInt(250)+100;


        for (int i = 0; i < quantityList.length; i++) {
            System.out.println(" Starting Quantity of " + itemList[i] + " is " + quantityList[i]);
        }
        int day = 0;
        System.out.println("---------------------------------------------------");

        do{

            //DAY () OF SALES
            day += 1;
            System.out.println(" Day " + day + " of Sales:");

            //CUSTOMERS BUYING PRODUCTS EVERYDAY AND RANDOM QUANTITIES
             quantityList[0] -= random.nextInt(15)+5;
             quantityList[1] -= random.nextInt(15)+5;
             quantityList[2] -= random.nextInt(15)+5;
             quantityList[3] -= random.nextInt(15)+5;
             quantityList[4] -= random.nextInt(15)+5;
             quantityList[5] -= random.nextInt(15)+5;
             quantityList[6] -= random.nextInt(15)+5;
             
            for (int i = 0; i < quantityList.length; i++) {

                System.out.println(" Next Day Quantity of " + itemList[i] + " is " + quantityList[i]);
            }

            System.out.println("---------------------------------------------------");

        }while (quantityList[0] >= 20 && quantityList[1] >= 20 && quantityList [2] >= 20 && quantityList [3] > 20 && quantityList[4] > 20 && quantityList [5] > 20 && quantityList [6] > 20);


            //ELSE IF STATEMENT TO GIVE THE RESTOCK NOTIFICATION
            if (quantityList[0] <= 20){
                System.out.println("RESTOCK ALERT: LOW QUANTITY OF COOKIES, REORDER NOW");
            }
            else if (quantityList [1] <= 20){
                System.out.println("RESTOCK ALERT: LOW QUANTITY OF BREAD, REORDER NOW");
            }
            else if (quantityList [2] <= 20){
                System.out.println("RESTOCK ALERT: LOW QUANTITY OF APPLES, REORDER NOW");
            }
            else if (quantityList [3] <= 20){
                System.out.println("RESTOCK ALERT: LOW QUANTITY OF PASTA, REORDER NOW");
            }
            else if (quantityList [4] <= 20){
                System.out.println("RESTOCK ALERT: LOW QUANTITY OF EGG, REORDER NOW");
            }
            else if (quantityList [5] <= 20){
                System.out.println("RESTOCK ALERT: LOW QUANTITY OF MILK, REORDER NOW");
            }
            else if (quantityList [6] <= 20){
                System.out.println("RESTOCK ALERT: LOW QUANTITY OF BACON, REORDER NOW");
            }

            //METHOD THAT GIVES THE START TEXT OF THE PROGRAM
    }
    public static void Intro() {
        System.out.println("---------------------------------------------------");
        System.out.println("Welcome to the Restock Notifier Program!");
        System.out.println();
        System.out.println("As a demonstration on how this program works, a list of stock numbers on common groceries wil be given,");
        System.out.println("and customers will begin to purchase items daily and as quantity for a product reaches below 15 a restock notification will appear.");
        System.out.println("---------------------------------------------------");
    }

}
